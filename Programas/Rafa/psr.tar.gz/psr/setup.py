from distutils.core import setup
from distutils.extension import Extension
from Cython.Distutils import build_ext
import numpy
import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

ext_modules = [Extension("distances",
                         ["psr/distances.pyx"],
                         libraries=["m"],
                         extra_compile_args=["-ffast-math"],
                         include_dirs=[numpy.get_include()]),]

setuptools.setup(
    name="psr",
    cmdclass={"build_ext": build_ext},
    ext_modules=ext_modules,
    version="1.0.0",
    author="José Rafael Cedeño González",
    author_email="jcgonzalez@dep.fie.umich.mx",
    description="Phase Space Reconstruction Methods",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="",
    packages=setuptools.find_packages(),
    # classifiers=[
    #     "Programming Language :: Python :: 3",
    #     "License :: OSI Approved :: MIT License",
    #     "Operating System :: OS Independent",
    # ],
)

# setup(
#     name="distances",
#     cmdclass={"build_ext": build_ext},
#     ext_modules=ext_modules,
#     include_dirs=[numpy.get_include()])
