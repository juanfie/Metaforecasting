# coding: utf-8
"""
Container for different methods to obtain the dimension, time delay and radius for time series forecasting with
phase space reconstruction.

Author: José Rafael Cedeño González
"""

import numpy as np
from psr.psr import PSR
import distances
from sklearn.neighbors.kd_tree import KDTree
from scipy.signal import argrelextrema
from itertools import groupby


class DeterministicMethod(object):

    def __init__(self, time_series):
        self.time_series = None
        if type(time_series) is not np.ndarray:
            self.time_series = np.array(time_series)
        elif type(time_series) is np.ndarray:
            self.time_series = time_series
        else:
            raise ValueError('Not a valid time series data type (list or numpy array only)')
        self.__m = None
        self.__tau = None
        self.__epsilon = None
        self.__R_min = 15.0
        self.__R_inc = 5.0
        self.__A = 2.0

    def get_tau(self):
        return self.__tau

    def set_tau(self, t):
        self.__tau = t

    def get_m(self):
        return self.__m

    def set_m(self, m):
        self.__m = m

    def set_R_min(self, r):
        self.__R_min = r

    def set_R_inc(self, ri):
        self.__R_inc = ri

    def set_A(self, a):
        self.__A = a

    def full_operation(self, min_m, max_m, calculate_tau=True, calculate_epsilon=False, min_neighbors=50, path=None):
        """
        Calculates the whole thing
        :param min_m: Minimum embedding dimension
        :param max_m: Maximum embedding dimension (non inclusive)
        :param calculate_tau: Boolean to include the calculation of tau
        :param calculate_epsilon: Boolean to include the calculation of epsilon
        :param min_neighbors: Minimum number of neighbors for a radius
        :param path: Where to save the resulting database
        :return: the time series database
        """
        p = self.deterministic_method(min_m, max_m, calculate_tau, calculate_epsilon, min_neighbors)
        return self.obtain_database(path)

    def obtain_database(self, path=None):
        """
        Once that m and tau has been calculated it lets to save the database
        :param path: Location of the file if provided
        :return: the database
        """
        p = PSR(self.time_series, self.__m, self.__tau)
        return p.get_database(path)

    def deterministic_method(self, min_m, max_m, calculate_tau=True, calculate_epsilon=False, min_neighbors=50):
        """
        Deterministic Method: main method to obtain the dimension, time delay and epsilon for a given time series.
        :param min_m: Starting value of embedding dimension
        :param max_m: Finishing value of embedding dimension (not inclusive)
        :param calculate_tau: Boolean value to include the calculation of tau, default True
        :param calculate_epsilon: Boolean value to include the calculation of epsilon, default False
        :param min_neighbors: Minimum number of neighbors to be inside epsilon
        :return: m embedding dimension, tau time delay, and optionally epsilon radius
        """
        if calculate_tau:
            self.__tau = self.obtain_tau()
        else:
            self.__tau = 1
        self.__m = self.obtain_m(min_m, max_m)
        if calculate_epsilon:
            self.__epsilon = self.find_epsilon(self.__m, self.__tau, min_neighbors, 1e-3)
            return self.__m, self.__tau, self.__epsilon
        else:
            return self.__m, self.__tau

    def obtain_tau(self, t=0.01):
        """
        Method to obtain the time delay with the mutual information method.
        :param t: the threshold to consider if the derivative of the mutual information curve is over 0
        :return: the index of the first minimum if the mutual information curve is not monotonic, 1 otherwise
        """
        mi = distances.mutual_information(1, 80, 1, 0.1, self.time_series)
        df = distances.diff(np.array(mi))
        for d in df:
            if d > 0 + t:
                return argrelextrema(df, np.greater)[0][0]
        return 1

    def obtain_m(self, min_m, max_m, num=10):
        """
        This function obtains the spectrum of false neighbors as a function of R and retrieves the index of the false
        nearest neighbors curve that the ratio of false nearest neighbors is the lowest. For each curve the minimum is
        retrieved and grouped to check which repeats the most. The most repeated index is designated as the index of the
        best m value.
        This method is based on the False Nearest Neighbors algorithm by Abarbanel et. al.
        :param min_m: Starting m value
        :param max_m: Ending m value (not inclusive)
        :param num: number of points to calculate for the R spectrum
        :return: the embedding dimension
        """
        nn = self.false_nearest_neighbors(min_m, max_m, num)
        fnn_idx = nn.argmin(axis=0)
        idx_group = groupby(fnn_idx)
        index_lowest_ratio = max(idx_group, key=lambda k: len(list(k[1])))[0]
        ms = range(min_m, max_m)
        return ms[index_lowest_ratio]


    def false_nearest_neighbors(self, min_m, max_m, num):
        """
        Method to calculate the spectrum of false nearest neighbors as a function of R
        :param min_m: Starting m value
        :param max_m: Ending m value (not inclusive)
        :param num: number of points to calculate of the R spectrum
        :return: curves that compose the spectrum of the false nearest neighbors ratios as a function of R
        """
        fnn = []
        for m in range(min_m, max_m):
            f = []
            R = self.__R_min
            for i in range(num):
                f.append(self.fnn_abarbanel(m, self.__tau, R, self.__A))
                R += self.__R_inc
            fnn.append(f)
        return np.array(fnn)

    def fnn_abarbanel(self, m, tau, Rtol=15.0, Atol=2.0):
        """
        False nearest neighbors algorithm as described in "Determining embedding dimension for phase-space
        reconstruction using a geometrical construction" by Matthew B. Kennel, Reggie Brown, Henry D. I. Abarbanel.
        :param m: Embedding dimension to psr
        :param tau: Optimal time delay for the time series
        :param Rtol: R tolerance threshold for criterion 1
        :param Atol: A tolerance threshold for criterion 2
        :return: the ratio between the compliance of the criteria and the number of vectors
        """
        p = PSR(self.time_series, m, tau)
        vectors_m = p.time_series_database
        deltas_m = p.next_values_database
        tree = KDTree(vectors_m)

        ts_mean = np.mean(self.time_series)
        RA = np.sqrt(np.mean([(x - ts_mean)**2 for x in self.time_series]))

        dist, indexes_of_neighbors = tree.query(vectors_m, k=2)
        neighbors_m = vectors_m[[x[1] for x in indexes_of_neighbors]]

        Rdsq = distances.rdsqrt(vectors_m, neighbors_m)
        Rdp1sq = distances.rdp1sqrt(vectors_m, neighbors_m, np.array(deltas_m), m)

        ratios = np.sqrt(Rdp1sq / Rdsq)
        ras = np.sqrt(Rdp1sq) / RA
        fnn = np.sum([1 if r1 > Rtol or r2 > Atol else 0 for r1, r2 in zip(ratios, ras)])
        return fnn / float(vectors_m.shape[0])

    def find_epsilon(self, m, tau, min_neighbors, eps):
        """
        Method to obtain epsilon based on the number of desired number of neighbors
        :param m: embedding dimension
        :param tau: time delay
        :param min_neighbors: minimum number of neighbors
        :param eps: Starting value
        :return:
        """
        epsilon = eps
        found = False
        p = PSR(self.time_series, m, tau)
        while not found:
            eval_vector = p.time_series_database[-1]
            num_neighbors = len(p.obtain_neighbors_indexes(eval_vector, epsilon))
            if num_neighbors >= min_neighbors:
                found = True
            else:
                epsilon *= 1.2
        return epsilon
