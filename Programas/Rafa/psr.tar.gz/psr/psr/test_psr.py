import unittest
import numpy as np
from psr import PSR
import subprocess
import os


class TestPSR(unittest.TestCase):

    def test_create_database(self):
        ts = np.empty(50)
        p = PSR(ts, 3, 1)
        self.assertIsNotNone(p.time_series_database)

    def test_get_db(self):
        ts = np.empty(50000)
        p = PSR(ts, 3, 1)
        db = p.get_database()
        self.assertEqual(db.shape[0], 49997)

    def test_get_db_nv(self):
        ts = np.empty(50000)
        p = PSR(ts, 3, 2)
        nv = p.next_values_database
        db = p.time_series_database
        self.assertEqual(len(nv) + len(db), len(db) * 2)

    def test_write_db(self):
        ts = np.empty(50000)
        p = PSR(ts, 3, 1)
        folder = subprocess.run('pwd', stdout=subprocess.PIPE).stdout.decode('utf-8').replace('\n', '')
        db = p.get_database(path=folder + '/file.txt')
        os.remove(folder + '/file.txt')
        self.assertEqual(db, 1)

    def test_len_vector(self):
        ts = np.empty(50)
        p = PSR(ts, 3, 1)
        db = p.get_database()
        self.assertEqual(db.shape[1], 4)

    def test_return_neighbors(self):
        ts = np.zeros(50000)
        p = PSR(ts, 3, 1)
        idx = p.obtain_neighbors_indexes([0.0, 0.0, 0.0], 0.0)
        self.assertEqual(len(idx), 49997)


if __name__ == '__main__':
    t = TestPSR()
    t.run()
