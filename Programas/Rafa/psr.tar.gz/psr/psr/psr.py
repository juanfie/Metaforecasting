# coding: utf-8
"""
Phase Space Reconstruction
Class and methods for phase space reconstruction of time series
Author: José Rafael Cedeño González
version 1.0
"""

import numpy as np
import sys
import distances


class PSR(object):
    def __init__(self, ts, m: int, tau: int, h=1):
        self.time_series = None
        self.m = m
        self.tau = tau
        self.h = h
        self.time_series_database = []
        self.next_values_database = []
        self.create_database(ts)

    def get_database(self, path=None):
        if path is not None:
            self.write_db(path)
            return 1
        else:
            return np.hstack((self.time_series_database, [[x] for x in self.next_values_database]))

    def create_database(self, ts):
        """
        Creates the database with the given time series
        :return: This method does not have a return vale
        """
        if type(ts) is str:
            self.time_series = self.read_from_file(ts)
        elif type(ts) is list or type(ts) is np.ndarray:
            self.time_series = ts
        else:
            raise ValueError('Type of Time Series is not supported (path, list, or numpy ndarray supported)')
        self.extract_data()

    def obtain_neighbors_indexes(self, eval_vector, epsilon):
        """
        Naive search of neighbors of eval_vector
        :param eval_vector: The current situation to obtain its neighborhood
        :param epsilon: Radius of search
        :return: A list with the indexes of the neighbors around eval_vector given a self.radius
        """
        return distances.find_neighbors(self.time_series_database, np.array(eval_vector), float(epsilon))
    
    def extract_data(self):
        """
        Slices the raw data into a validation set and both representations of list and delay vectors
        :return: This method does not return value
        """
        self.time_series = np.array(self.time_series)
        self.extract_delay_vectors()
    
    def extract_delay_vectors(self):
        """
        Obtains the delay vectors of the time series in the form
        S_n = {S_{N - (m * \tau)} , ..., S_{N - \tau},  S_{N}}
        :return: This method does not return value
        """
        length_time_series = len(self.time_series)
        end = length_time_series - 1 - (self.m - 1) * self.tau
        for i in range(end):
            lapse = (self.m - 1) * self.tau + 1 + i
            temp = self.delay_reconstruction(i, lapse)
            if self.is_valid_delay_vector(temp):
                if self.h == 1:
                    if lapse < length_time_series:
                        self.next_values_database.append(self.insert_into_nv(lapse, many=False))
                        self.time_series_database.append(temp)
                else:
                    if lapse + self.h < length_time_series:
                        self.next_values_database.append(self.insert_into_nv(lapse, many=True))
                        self.time_series_database.append(temp)
        self.time_series_database = np.array(self.time_series_database)
        self.next_values_database = np.array(self.next_values_database)

    def insert_into_nv(self, lapse, many=False):
        deltas = np.zeros(self.h)
        j = 0
        for l in range(lapse, lapse + self.h):
            deltas[j] = self.time_series[l]
            j += 1
        if many:
            return deltas.tolist()
        else:
            return deltas[0]
    
    def delay_reconstruction(self, start, end):
        """
        Obtains the individual delay vector with the values [start, start + m * tau] in tau intervals
        :param start: The starting index in the time series of the value to construct the delay vector
        :param end: The ending index in the time series of the value to construct the delay vector
        :return: The delay vector delimited between start and end in time_delay steps
        """
        return np.array([self.time_series[i] for i in range(start, end, self.tau)])

    @staticmethod
    def read_file_dat(path: str) -> list:
        data = None
        with open(path, 'r') as f:
            data = [float(x) for x in f.readlines()]
        return data

    @staticmethod
    def read_file_csv(path: str) -> list:
        data = None
        with open(path, 'r') as f:
            data = [float(str(x).split(',')[1]) for x in f.readlines()]
        return data
    
    def read_from_file(self, ts: str):
        """
        Loads the data of a time series contained in a file into a list
        :param ts: The path to the file that contains the time series
        :return: The time series data in form of a list
        """
        data_read_function = None
        if ts.find('.dat') != -1:
            data_read_function = self.read_file_dat
        elif ts.find('.csv') != -1:  # expects a format of date, value
            data_read_function = self.read_file_csv
        else:
            raise ValueError("Unexpected file format.")
        data = None
        try:
            data = data_read_function(ts)
        except IOError as e:
            print("I/O error({0}): {1}".format(e.errno, e.strerror))
        except:
            print("Unexpected error:", sys.exc_info()[0])
        return data

    @staticmethod
    def is_valid_delay_vector(vector):
        """
        Checks if the given vector does not contains a -1 in it
        :param vector: The vector to evaluate
        :return: True if a -1 is contained in vector, False otherwise
        """
        return not (-1 in vector)
    
    def write_db(self, path):
        """
        Writes into a file the content of the time series database and the next values database.
        :param path: The path to the file to store the data
        :return: This method does not return value
        """
        with open(path, 'w') as f:
            for v, nv in zip(self.time_series_database, self.next_values_database):
                line = ''
                for i in range(self.m):
                    line += str(v[i]) + ', '
                if self.h == 1:
                    line += str(nv)
                else:
                    for i in range(self.h):
                        line += str(nv[i]) + ', '
                line = line.rstrip().rstrip(',')
                f.write(str(line) + '\n')
