import unittest
import numpy as np
from psr.methods import DeterministicMethod
import subprocess
import os


class TestDeterministMethod(unittest.TestCase):
    def test_fnn(self):
        ts = np.ones(5000)
        dm = DeterministicMethod(ts)
        m, tau = dm.deterministic_method(2, 3)

    def test_list(self):
        ts = np.ones(5000).tolist()
        dm = DeterministicMethod(ts)
        m, tau = dm.deterministic_method(2, 3)

    def test_full_operation(self):
        ts = np.ones(5000).tolist()
        dm = DeterministicMethod(ts)
        db = dm.full_operation(2, 3)
        self.assertIsNotNone(db)


if __name__ == '__main__':
    tdm = TestDeterministMethod()
    tdm.run()
