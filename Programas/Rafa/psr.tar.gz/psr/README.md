**Phase Space Reconstruction Methods.**

This package contains a couple of classes that provide phase space reconstruction for time series.

Usage for database creation:

`from psr import PSR`

Loads a time series (path, list or numpy array) and with the given m and tau converts it to delay vectors

`psr = PSR(ts, 3, 1)`

To obtain the delay vectors and its next values simply invoke get_database (if a path is provided the database 
can be stored into a file)

`ts_db = psr.get_database()`

Usage to determine m and tau by using the deterministic method:

`from methods import DeterministicMethod`

Load a time series (list or numpy array, not path) and calculates m and tau with the deterministic method

`dm = DeterministicMethod(ts)`

`m, tau = dm.deterministic_method(2, 7)`

If you are feeling bold and risky:

`db = dm.full_operation(2, 7)`

This will obtain m and tau and then make a database with the calculated parameters.

